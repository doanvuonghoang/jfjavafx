/**
 * Top level package for information broker options.     
 *
 * @since 1.0
 */
package net.xeoh.plugins.informationbroker.options;