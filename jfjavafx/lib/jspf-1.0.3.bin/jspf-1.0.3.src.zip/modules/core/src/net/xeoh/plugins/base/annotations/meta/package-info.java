/**
 * Annotations related to plugin information.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.annotations.meta;