/**
 * Annotations related to plugin loading.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.annotations.configuration;