/**
 * Annotations related to injecting variables.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.annotations.injections;