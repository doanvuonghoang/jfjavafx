/**
 * Some utilities and wrappers for other objects / interfaces.      
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.util;