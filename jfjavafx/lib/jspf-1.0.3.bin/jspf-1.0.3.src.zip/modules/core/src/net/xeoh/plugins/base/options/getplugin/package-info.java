/**
 * Options to <code>getPlugin()</code>.    
 *
 * @since 1.0
 */
package net.xeoh.plugins.base.options.getplugin;